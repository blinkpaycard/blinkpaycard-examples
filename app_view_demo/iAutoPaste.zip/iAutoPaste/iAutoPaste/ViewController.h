//
//  ViewController.h
//  iAutoPaste
//
//  Created by hongxi on 2019/1/8.
//  Copyright © 2019 hongxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

