//
//  ViewController.m
//  iAutoPaste
//
//  Created by hongxi on 2019/1/8.
//  Copyright © 2019 hongxi. All rights reserved.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>

@interface ViewController () <WKNavigationDelegate, WKUIDelegate>

@end

@implementation ViewController {
    WKWebView *_webView;
}

/**
    ① 打开淘宝App，需要在info.plist文件中增加LSApplicationQueriesSchemes（类型为Array），然后在这个类型下面新增一个item为String类型，值设置为taobao
    ② 测试连接不是https, 需要在info.plist文件中增加App Transport Security Settings (类型为Dictionary)，然后在这个类型下面新增一个Allow Arbitrary Loads元素，值设置为true
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 1、创建网页配置对象
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    // 2、添加设置对象WKPreferences, 允许使用Javascript
    WKPreferences *preference = [[WKPreferences alloc]init];
    preference.javaScriptEnabled = YES;
    preference.javaScriptCanOpenWindowsAutomatically = YES;
    config.preferences = preference;
    
    // 3、创建webview，设置它的代理并添加到界面中
    _webView = [[WKWebView alloc] initWithFrame:self.view.frame configuration:config];
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@""]]];
    _webView.navigationDelegate = self;
    _webView.UIDelegate = self;
    [self.view addSubview:_webView];
    

    // 加载本地测试html文件
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"test" ofType:@"html"];
//    NSString *htmlString = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
//    NSString *basePath = [[NSBundle mainBundle] bundlePath];
//    NSURL *baseURL = [NSURL fileURLWithPath:basePath];
//    [_webView loadHTMLString:htmlString baseURL:baseURL];
    
    // 加载线上url
     NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString: @"http://blink.nodemall.com/special"]];
     [_webView loadRequest:request];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    // 注册返回App事件, 每次返回App就调用自定义的applicationDidBecomeActive方法
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive)name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    // 取消注册重新回到App事件
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// 自定义方法
- (void)applicationDidBecomeActive{
    // 其它操作
    [self passClipBoardDataToWebView];
}

// 拦截taobao://的跳转请求打开淘宝App
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    if ([navigationAction.request.URL.scheme isEqual:@"taobao"]){
        if([[UIApplication sharedApplication]canOpenURL:navigationAction.request.URL])
        {
            [[UIApplication sharedApplication]openURL:navigationAction.request.URL];
            decisionHandler(WKNavigationActionPolicyCancel);
            
        }else{
            decisionHandler(WKNavigationActionPolicyAllow);
        }
        
    }else{
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

// 网页加载完成后检查一次剪切板（用于首次进入App时检查）
- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    // 延迟1秒再用webview执行js代码, 否则有时传不成功
    [self performSelector:@selector(passClipBoardDataToWebView) withObject:nil afterDelay:1.0];
}

// 传递剪切板内容到webview中
- (void)passClipBoardDataToWebView {
    NSString *pasteString = UIPasteboard.generalPasteboard.string;
    if (pasteString != nil) {
        NSString *urlEncodeString = [pasteString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLPathAllowedCharacterSet]];
        NSString *jsCode = [NSString stringWithFormat:@"getPasteInfo('%@')", urlEncodeString];
        // 传入到webview中
        [_webView evaluateJavaScript:jsCode completionHandler:nil];
    }
}



@end
