package com.hongxi.autopaste;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.net.URLEncoder;

public class MainActivity extends Activity {

    // 记得在AndroidManifest.xml文件加上联网权限
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 获得在activity_main中定义的webView控件
        webView = (WebView)findViewById(R.id.webview);

        // webView 相关设置，主要是setJavaScriptEnabled这个设置, 允许运行JavaScript脚本
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setJavaScriptEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setAppCacheEnabled(true);
        settings.setDomStorageEnabled(true);

        // 设置webViewClient，否则会调用系统浏览器打开链接
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // 首次打开App也要检查一次剪切板
                passClipBoardDataToWebView();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // 如果要打开淘宝，需要自己用Intent跳转到淘宝
                if (url.startsWith("taobao:")) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    Uri uri = Uri.parse(url);
                    intent.setData(uri);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    MainActivity.this.startActivity(intent);
                    return true;
                }
                view.loadUrl(url);
                return true;
            }
        });

        // webView.loadUrl("file:///android_asset/test.html"); // 本地测试
        // 打开网页
        webView.loadUrl("http://blink.nodemall.com/special");


    }

    /**
     * 每次切换回App会触发这个onResume方法
     */
    @Override
    protected void onResume() {
        super.onResume();
        // 每次切换回App检查一次剪切板
        passClipBoardDataToWebView();
    }

    private void passClipBoardDataToWebView() {
        // 获取剪切板内容
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        ClipData clipData = cm.getPrimaryClip();
        String data = clipData.getItemAt(0).getText().toString();

        if (!data.trim().equals("")) {
            // 执行js脚本, 把内容传到webView（需要encode处理, 前端再decodeURIComponent恢复）
            webView.evaluateJavascript("javascript:getPasteInfo('" + URLEncoder.encode(data) + "')", null);

        }
    }

}
